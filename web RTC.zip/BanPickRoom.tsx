import {NextPage} from "next";
import styled from "@emotion/styled";
import {Button} from "@nextui-org/react";
import {useEffect, useState} from "react";
import Peer from "peerjs";

const BanPickRoom: NextPage = () => {

    const [peer, setPeer] = useState<Peer>();

    useEffect(() => {
        import('peerjs').then(({ default: Peer }) => {
            const nowPeer = new Peer('test1', {
                host: '100.108.189.101',
                port: 9000,
                path: '/myapp',
            });

            setPeer(nowPeer);

            nowPeer.on('open', function(id) {
                console.log('My peer ID is: ' + id);
            });

            nowPeer.on('connection', function(conn) {
                conn.on('data', function(data) {
                    // Will print 'hi!'
                    console.log(data);
                });
            });
        });
    }, []);


    const onClickButton = () => {
        console.log("in");
        const conn = peer?.connect('test1');
        conn?.on('open', function() {
            conn.send('hi from 1!');
        });
    }
    return (
        <BanPickRoomWrapper>
            <Button onClick={() => onClickButton()}>Button</Button>
        </BanPickRoomWrapper>
    );
}

export default BanPickRoom;

const BanPickRoomWrapper = styled.div`
`
