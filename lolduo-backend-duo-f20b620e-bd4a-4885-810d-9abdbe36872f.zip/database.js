import mysql from 'mysql2/promise';

export default class Database {


    constructor() {
        this.connection =  mysql.createConnection({
            host: 'mysql-database.cpkc4mgsoy1b.ap-northeast-2.rds.amazonaws.com',
            user: 'root',
            password: 'fhfebdh1!',
            database: 'riot'
        });
    }
    async getDuo(id1, id2, position1, position2){
        let connection = await this.connection;
        const totalGame = 100;

        const defaultPaging = 20;
        let query = 
        `
        SELECT 
        	#champion1 info
        	champion1.id as champion1_id,
        	champion1.name_id as champion1_name_id,
            champion1.ko_name as champion1_name,
            union_table.combi1_lane as champion1_lane,
            perk1.name_id as champion1_perk,
            #cahmpion2 info
            champion2.id as champion2_id,
        	champion2.name_id as champion2_name_id,
            champion2.ko_name as champion2_name,
            union_table.combi2_lane as champion2_lane,
            perk2.name_id as champion2_perk,
            #duo info
            union_table.win_rate,
            union_table.win,
            union_table.lose
        FROM (
        	SELECT * 
        	FROM (
        			SELECT
            			combi1.combi_id as combi1_id,			
            			combi1.champion_id as combi1_champion_id,
            			combi1.lane as combi1_lane,
            			combi1.main_perk as combi1_perk,
            			combi2.combi_id as combi2_id,
            			combi2.champion_id as combi2_champion_id,
            			combi2.lane as combi2_lane,
            			combi2.main_perk as combi2_perk,
            			mdi.win_rate,
            			mdi.win,
            			mdi.lose
            		FROM match_duo_info mdi
            		LEFT JOIN combi combi1
            		ON mdi.combi_id_1 =combi1.combi_id 
            		LEFT JOIN combi combi2
            		ON mdi.combi_id_2 =combi2.combi_id
            		WHERE (mdi.win + mdi.lose) > ?
        `;
    const values = [totalGame];
    
    if (id1 != 0) {
        query += ` AND combi1.champion_id = ?`;
        values.push(parseInt(id1));
    }
    if (id2 != 0) {
        query += ` AND combi2.champion_id = ?`;
        values.push(parseInt(id2));
    }    
    if (position1 != "ALL") {
        query += ` AND combi1.lane = ?`;
        values.push(position1);
    }
    if (position2 != "ALL") {
        query += ` AND combi2.lane = ?`;
        values.push(position2);
    }
    query += " ORDER BY mdi.win_rate DESC LIMIT " + defaultPaging;
    
    query += 
    `
            ) case1
	        UNION
        	SELECT * FROM (
        		SELECT
        			combi2.combi_id as combi1_id,
        			combi2.champion_id as combi1_champion_id,
        			combi2.lane as combi1_lane,
        			combi2.main_perk as combi1_perk,
        			combi1.combi_id as combi2_id,			
        			combi1.champion_id as combi2_champion_id,
        			combi1.lane as combi2_lane,
        			combi1.main_perk as combi2_perk,
        			mdi.win_rate,
        			mdi.win,
        			mdi.lose
        		FROM match_duo_info mdi
        		LEFT JOIN combi combi1
        		ON mdi.combi_id_1 =combi1.combi_id 
        		LEFT JOIN combi combi2
        		ON mdi.combi_id_2 =combi2.combi_id
        		WHERE (mdi.win + mdi.lose) > ?
    `;
    values.push(totalGame);
    if (id1 != 0) {
        query += ` AND combi2.champion_id = ?`;
        values.push(parseInt(id1));
    }
    if (id2 != 0) {
        query += ` AND combi1.champion_id = ?`;
        values.push(parseInt(id2));
    }    
    if (position1 != "ALL") {
        query += ` AND combi2.lane = ?`;
        values.push(position1);
    }
    if (position2 != "ALL") {
        query += ` AND combi1.lane = ?`;
        values.push(position2);
    }
    query += " ORDER BY mdi.win_rate DESC LIMIT " + defaultPaging;
    query +=
    `
            ) case2
    ) union_table
    LEFT JOIN champion champion1
    ON union_table.combi1_champion_id = champion1.id
    LEFT JOIN champion champion2
    ON union_table.combi2_champion_id = champion2.id
    LEFT JOIN perk perk1
    ON union_table.combi1_perk = perk1.id 
    LEFT JOIN perk perk2
    ON union_table.combi2_perk = perk2.id  
    ORDER BY union_table.win_rate DESC 
    LIMIT 
    `
    query +=defaultPaging;
    
    const [rows] = await connection.execute(query, values);
    let result = [];
    let i = 0;
    
    rows.forEach(element => {
        result[i] = {
        id1: element.champion1_id,
        id2: element.champion2_id,
        rankChangeImgUrl:"https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/rankChange/RankSame.svg",
        rankChangeNumber: 0,
        champion1: {
            championName: element.champion1_name,
            championImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/champion/${element.champion1_name_id}.svg`,
            mainRuneImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/mainRune/${element.champion1_perk}.svg`,
            positionImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/position/${element.champion1_lane}.svg`,
        },
        champion2: {
            championName: element.champion2_name,
            championImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/champion/${element.champion2_name_id}.svg`,
            mainRuneImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/mainRune/${element.champion2_perk}.svg`,
            positionImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/position/${element.champion2_lane}.svg`,
        },
        winRate: (element.win_rate / 100).toFixed(2) + "%",
        totalGames: element.win + element.lose,
        rankNumber: 1+i++
        };
    })
    
    connection.end(function(err) {
        if (err) {
            console.error('Error closing the connection:', err);
        } else {
            console.log('Connection closed successfully.');
        }
    });
    
    return result;
    }
}