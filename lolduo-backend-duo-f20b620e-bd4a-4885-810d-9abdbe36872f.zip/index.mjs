import Database from "./database.js";

class app {

    async start(id1, id2, position1, position2) {
        let database = new Database();
        let top20Results = await database.getDuo(id1, id2, position1, position2);
        return top20Results;
    }
}

export const handler = async (event, context, callback) => {
    let param; 
    if(event.queryStringParameters !==null){
        param = event.queryStringParameters;
        if(param?.championId==null || param?.championId2==null || param?.position==null || param?.position2==null){
            return {
                statusCode: 400,
                body: JSON.stringify("권한이 없습니다."),
            };
        }
    }
    else{
        return {
          statusCode: 400,
          body: JSON.stringify("권한이 없습니다."),
        };
    }
    let app1 = new app();
    let now = await app1.start(param.championId, param.championId2, param.position, param.position2);
    
    callback(null,{
        statusCode: 200,
        body: JSON.stringify(now),
    });

}