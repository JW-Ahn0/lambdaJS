import {createClient} from "redis";
import crypto from 'crypto';


class CreateRoomId{
  constructor() {
    this.regenerateRoomId();
  }
  regenerateRoomId(){
    this.roomId = crypto.createHash('sha1').update(new Date().getTime() + "").digest('hex') + Math.floor(Math.random() * 1000) + "";
    return this.roomId;
  }
}

export const handler = async (event) => {
    const connectionId = event.requestContext.connectionId;

    let data = JSON.parse(event.body);
    let createRoomId  = new CreateRoomId();
    let roomId = createRoomId.roomId;

    const redisClient = createClient({
      url: "redis://redis.uxqk8e.ng.0001.apn2.cache.amazonaws.com:6379",
      legacyMode: true,
    });
    redisClient.on("error", (error) => {
      console.log(error);
    });
    redisClient.connect().then(); // redis v4 연결 (비동기)
    const redisCli = redisClient.v4;

    let isIdExist =  await redisCli.exists(roomId);

    while(isIdExist){
      roomId = createRoomId.regenerateRoomId();
      isIdExist = await redisCli.exists(roomId);
    }

    await redisCli.quit();
    
    return {
      statusCode: 200,
      body: JSON.stringify({id: roomId}),
    };
};