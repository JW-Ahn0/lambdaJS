import mysql from 'mysql2/promise';

export default class Database {


    constructor() {
        this.connection =  mysql.createConnection({
            host: 'mysql-database.cpkc4mgsoy1b.ap-northeast-2.rds.amazonaws.com',
            user: 'root',
            password: 'fhfebdh1!',
            database: 'riot'
        });
    }
    async getDuo(id1, id2, position1, position2){
        let connection = await this.connection;
        const totalGame = 100;

        const defaultPaging = 20;
        let query = 
        `
        SELECT 
        	#champion1 info
        	champion1.id as champion1_id,
        	champion1.name_id as champion1_name_id,
            champion1.ko_name as champion1_name,
            one_table.combi1_lane as champion1_lane,
            perk1.name_id as champion1_perk,
            #cahmpion2 info
            champion2.id as champion2_id,
        	champion2.name_id as champion2_name_id,
            champion2.ko_name as champion2_name,
            one_table.combi2_lane as champion2_lane,
            perk2.name_id as champion2_perk,
            #duo info
            one_table.win_rate,
            one_table.win,
            one_table.lose
        FROM 
            (
        		SELECT
        			combi1.combi_id as combi1_id,			
        			combi1.champion_id as combi1_champion_id,
        			combi1.lane as combi1_lane,
        			combi1.main_perk as combi1_perk,
        			#ㅇㅇㅇ
        			combi2.combi_id as combi2_id,
        			combi2.champion_id as combi2_champion_id,
        			combi2.lane as combi2_lane,
        			combi2.main_perk as combi2_perk,
        			#ㅇㅇㅇ
        			mdi.win_rate,
        			mdi.win,
        			mdi.lose
        		FROM match_duo_info mdi
        		LEFT JOIN combi combi1
        		ON mdi.combi_id_1 =combi1.combi_id 
        		LEFT JOIN combi combi2
        		ON mdi.combi_id_2 =combi2.combi_id
        		WHERE (mdi.win + mdi.lose) > ?
        		AND
        		(
        		    (
        		    1=1
        `;
    const values = [totalGame];
    
    if (id1 != 0) {
        query += ` AND combi1.champion_id = ?`;
        values.push(parseInt(id1));
    }
    if (id2 != 0) {
        query += ` AND combi2.champion_id = ?`;
        values.push(parseInt(id2));
    }    
    if (position1 != "ALL") {
        query += ` AND combi1.lane = ?`;
        values.push(position1);
    }
    if (position2 != "ALL") {
        query += ` AND combi2.lane = ?`;
        values.push(position2);
    }
    query +=
    `
                    )
                    OR
                    (
                    1=1
    `;
    if (id1 != 0) {
        query += ` AND combi2.champion_id = ?`;
        values.push(parseInt(id1));
    }
    if (id2 != 0) {
        query += ` AND combi1.champion_id = ?`;
        values.push(parseInt(id2));
    }    
    if (position1 != "ALL") {
        query += ` AND combi2.lane = ?`;
        values.push(position1);
    }
    if (position2 != "ALL") {
        query += ` AND combi1.lane = ?`;
        values.push(position2);
    }    
    query += 
    `
                    )
                )
                ORDER BY mdi.win_rate DESC LIMIT 
    `;
    query += defaultPaging;
    query += 
    `
            ) one_table
        LEFT JOIN champion champion1
        ON one_table.combi1_champion_id = champion1.id
        LEFT JOIN champion champion2
        ON one_table.combi2_champion_id = champion2.id
        LEFT JOIN perk perk1
        ON one_table.combi1_perk = perk1.id 
        LEFT JOIN perk perk2
        ON one_table.combi2_perk = perk2.id 
    `;
    const [rows] = await connection.execute(query, values);
    let result = [];
    let i = 0;
    
    rows.forEach(element => {
        result[i] = {
        id1: element.champion1_id,
        id2: element.champion2_id,
        rankChangeImgUrl:"https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/rankChange/RankSame.svg",
        rankChangeNumber: 0,
        champion1: {
            championName: element.champion1_name,
            championImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/champion/${element.champion1_name_id}.svg`,
            mainRuneImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/mainRune/${element.champion1_perk}.svg`,
            positionImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/position/${element.champion1_lane}.svg`,
        },
        champion2: {
            championName: element.champion2_name,
            championImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/champion/${element.champion2_name_id}.svg`,
            mainRuneImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/mainRune/${element.champion2_perk}.svg`,
            positionImgUrl: `https://s3.ap-northeast-2.amazonaws.com/img.lol-duo/mainPage/position/${element.champion2_lane}.svg`,
        },
        winRate: (element.win_rate / 100).toFixed(2) + "%",
        totalGames: element.win + element.lose,
        rankNumber: 1+i
        };
        if (id1 !== 0 && id1 !==result[i].id1) {
            this.swapChampion(result[i]);
        }
        if (id2 !== 0 && id2 !== result[i].id2) {
            this.swapChampion(result[i]);
        }    
        if (position1 !== "ALL" && position1 !== element.champion1_lane) {
            this.swapChampion(result[i]);
        }
        if (position2 !== "ALL" && position2 !== element.champion2_lane) {
            this.swapChampion(result[i]);
        } 
        i++;
    })
    
    connection.end(function(err) {
        if (err) {
            console.error('Error closing the connection:', err);
        } else {
            console.log('Connection closed successfully.');
        }
    });
    
    return result;
    }
    swapChampion(resultObject) {
        const temp = resultObject.champion1;
        resultObject.champion1 = resultObject.champion2;
        resultObject.champion2 = temp;
    }

}